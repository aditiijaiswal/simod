"""#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from math import radians


class Square:
    def __init__(self):
        rospy.init_node('square_turtle', anonymous=False)

        self.velocity_publisher = rospy.Publisher(
            '/turtle1/cmd_vel', Twist, queue_size=10)
        self.pose_subscriber = rospy.Subscriber(
            '/turtle1/pose', Pose, self.update_pose)

        self.pose = Pose()

    def update_pose(self, data):
        self.pose = data

    def move(self, linear_vel, angular_vel, duration):
        vel_msg = Twist()
        vel_msg.linear.x = linear_vel
        vel_msg.angular.z = angular_vel

        t0 = rospy.Time.now().to_sec()
        current_distance = 0
        rate = rospy.Rate(10)

        while current_distance < duration:
            self.velocity_publisher.publish(vel_msg)
            t1 = rospy.Time.now().to_sec()
            current_distance = linear_vel * (t1 - t0)
            rate.sleep()

        vel_msg.linear.x = 0
        vel_msg.angular.z = 0
        self.velocity_publisher.publish(vel_msg)

    def rotate(self, angle):
        angular_speed = radians(45)
        relative_angle = radians(angle)

        vel_msg = Twist()
        vel_msg.linear.x = 0
        vel_msg.angular.z = angular_speed

        t0 = rospy.Time.now().to_sec()
        current_angle = 0
        rate = rospy.Rate(10)

        while current_angle < relative_angle:
            self.velocity_publisher.publish(vel_msg)
            t1 = rospy.Time.now().to_sec()
            current_angle = angular_speed * (t1 - t0)
            rate.sleep()

        vel_msg.linear.x = 0
        vel_msg.angular.z = 0
        self.velocity_publisher.publish(vel_msg)

    def draw_square(self):
        self.move(1, 0, 3)  # move forward for 3 seconds
        self.rotate(90)     # rotate 90 degrees
        self.move(1, 0, 3)  # move forward for 3 seconds
        self.rotate(90)     # rotate 90 degrees
        self.move(1, 0, 3)  # move forward for 3 seconds
        self.rotate(90)     # rotate 90 degrees
        self.move(1, 0, 3)  # move forward for 3 seconds


if __name__ == '__main__':
    try:
        square = Square()
        square.draw_square()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass"""
        
"""#!/usr/bin/env python3
import rospy
import math
from geometry_msgs.msg import Twist

def square_movement_node():
	pub = rospy.Publisher("/turtle1/cmd_vel", Twist,queue_size=10)
	rospy.init_node("tb_sim_sq", anonymous=True)
	vel_msg = Twist()
	distance = 10
	duration = 10
	rate = rospy.Rate(10)
	pi = math.pi
	vel_msg.linear.x = 0.3
	vel_msg.linear.y = 0
	vel_msg.linear.z = 0
	vel_msg.angular.x = 0
	vel_msg.angular.y = 0
	vel_msg.angular.z = 0
	while not rospy.is_shutdown():
		while(True):
			t0 = rospy.Time.now().to_sec()
			current_distance = 0
			
			while(current_distance < distance):
				pub.publish(vel_msg)
				t1 = rospy.Time.now().to_sec()
				current_distance = 10*(t1-t0)
				
			rospy.Rate(10).sleep()
			vel_msg.linear.x = 0
			vel_msg.angular.z = pi*2/4/duration
			pub.publish(vel_msg)
			vel_msg.angular.z = 0
			pub.publish(vel_msg)
			
if __name__ == "__main__":
square_movement_node()"""

import rospy
from geometry_msgs.msg import Twist
from math import radians

class DrawASquare():
    def __init__(self):
        # initiliaze
        rospy.init_node('drawasquare', anonymous=False)

        # What to do you ctrl + c    
        rospy.on_shutdown(self.shutdown)
        
        self.cmd_vel = rospy.Publisher('cmd_vel_mux/input/navi', Twist, queue_size=10)
     
	# 5 HZ
        r = rospy.Rate(5);

	# create two different Twist() variables.  One for moving forward.  One for turning 45 degrees.

        # let's go forward at 0.2 m/s
        move_cmd = Twist()
        move_cmd.linear.x = 0.2
	# by default angular.z is 0 so setting this isn't required

        #let's turn at 45 deg/s
        turn_cmd = Twist()
        turn_cmd.linear.x = 0
        turn_cmd.angular.z = radians(45); #45 deg/s in radians/s

	#two keep drawing squares.  Go forward for 2 seconds (10 x 5 HZ) then turn for 2 second
	count = 0
        while not rospy.is_shutdown():
	    # go forward 0.4 m (2 seconds * 0.2 m / seconds)
	    rospy.loginfo("Going Straight")
            for x in range(0,10):
                self.cmd_vel.publish(move_cmd)
                r.sleep()
	    # turn 90 degrees
	    rospy.loginfo("Turning")
            for x in range(0,10):
                self.cmd_vel.publish(turn_cmd)
                r.sleep()            
	    count = count + 1
	    if(count == 4): 
                count = 0
	    if(count == 0): 
                rospy.loginfo("TurtleBot should be close to the original starting position (but it's probably way off)")
        
    def shutdown(self):
        # stop turtlebot
        rospy.loginfo("Stop Drawing Squares")
        self.cmd_vel.publish(Twist())
        rospy.sleep(1)
 
if __name__ == '__main__':
    try:
        DrawASquare()
    except:
        rospy.loginfo("node terminated.")
