#!/usr/bin/env python3
import rospy
from std_msgs.msg import String
name_list = ["VITCC","ROS","ADITI","20BRS1184"]
def publish_name():
	rospy.init_node("name_publisher", anonymous=True)
	pub = rospy.Publisher("name", String, queue_size = 3)
	rate = rospy.Rate(1)
	while not rospy.is_shutdown():
		for string in name_list:
			rospy.loginfo("Published name -> " + string)
			pub.publish(string)
			rate.sleep()
if __name__ == "__main__":
	try:
		publish_name()
	except rospy.ROSInterruptException:
		pass

